/* eslint-disable no-undef */
const assert = require('assert');

Feature('Favoriting and Unfavoriting Restaurants');

Before(({ I }) => {
  I.amOnPage('/#/favorite');
});

Scenario('showing empty favorited restaurants', ({ I }) => {
  I.seeElement('#restaurants');
  I.see('Tidak ada restaurant untuk ditampilkan', '#restaurant-item__not__found');
});

Scenario('favoriting one restaurant', async ({ I }) => {
  // I.seeElement('#restaurant-list');
  I.see('Tidak ada restaurant untuk ditampilkan', '#restaurant-item__not__found');

  I.amOnPage('/');
  I.wait(3);

  // I.waitForElement('#restaurant-item');
  I.seeElement('#restaurant__name a');

  const firstRestaurant = locate('#restaurant__name a').first();
  const firstRestaurantName = await I.grabTextFrom(firstRestaurant);
  I.click(firstRestaurant);
  I.wait(3);

  I.seeElement('#favoriteButton');
  I.click('#favoriteButton');
  I.wait(3);

  I.amOnPage('/#/favorite');
  I.wait(3);
  I.seeElement('#restaurant-item');
  const favoritedRestaurantName = await I.grabTextFrom('#restaurant__name');

  assert.strictEqual(firstRestaurantName, favoritedRestaurantName);
});

Scenario('unfavoriting one restaurant', async ({ I }) => {
  I.wait(5);
  I.see('Tidak ada restaurant untuk ditampilkan', '#restaurant-item__not__found');

  I.amOnPage('/');

  // I.waitForElement('.restaurant-item');
  I.seeElement('#restaurant__name a');

  const firstRestaurant = locate('#restaurant__name a').first();
  const firstRestaurantName = await I.grabTextFrom(firstRestaurant);
  I.click(firstRestaurant);
  I.wait(10);

  I.seeElement('#favoriteButton');
  I.click('#favoriteButton');
  I.wait(3);

  I.amOnPage('/#/favorite');
  I.seeElement('restaurant-item');
  const favoritedRestaurantName = await I.grabTextFrom('#restaurant_name');
  assert.strictEqual(firstRestaurantName, favoritedRestaurantName);

  I.click(locate('#restaurant__name a').first());

  I.seeElement('#favoriteButton');
  I.click('#favoriteButton');

  I.amOnPage('/#/favorite');
  I.see('Tidak ada restaurant untuk ditampilkan', '#restaurant-item__not__found');

  // I.seeElement('restaurant-item a');
  // const firstRestaurantFavorite = locate('#resto__name a').first();
  // const favoritedRestaurantName = await I.grabTextFrom(firstRestaurantFavorite);
  // assert.strictEqual(firstRestaurantName, favoritedRestaurantName);
  // I.click(firstRestaurantFavorite);
  // I.wait(10);
  // I.seeElement('#favoriteButton');
  // I.click('#favoriteButton');
  // I.wait(3);
  // I.amOnPage('/#/favorite');
  // I.wait(3);
  // I.seeElement('#restaurant-item__not__found');
  // const onFav = await I.grabTextFrom('#restaurant-item__not__found');
  // assert.strictEqual(onFav, 'Tidak ada restaurant untuk ditampilkan');
});
